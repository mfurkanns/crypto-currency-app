package com.example.staj;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;



public class CoinGoster extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_goster);

        TextView isim = (TextView) findViewById(R.id.name);
        TextView description = (TextView)findViewById(R.id.description);
        TextView price = (TextView)findViewById(R.id.price);
        Button buton = (Button) findViewById(R.id.button);

        String color ;
        Intent i = getIntent();

        color = i.getStringExtra("color");

        if(color.length()!=4){
            isim.setTextColor(Color.parseColor(color));
            description.setTextColor(Color.parseColor(color));
            price.setTextColor(Color.parseColor(color));
        }

        isim.setText(i.getStringExtra("name"));
        description.setText(i.getStringExtra("description"));
        price.setText("$ "+i.getStringExtra("price"));



        String url = i.getStringExtra("url");
        System.out.println(url);

        buton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(CoinGoster.this,MainActivity.class);
                startActivity(i);
            }
        });


    }


}
