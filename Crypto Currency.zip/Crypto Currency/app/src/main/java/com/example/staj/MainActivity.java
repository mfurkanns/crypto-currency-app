package com.example.staj;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    JSONArray coins;
    HashMap pairs = new HashMap<Integer, Integer>();  // hangi textview'ın hangi kripto parayı gösterdiği tutulur <TextViewId,kriptoParaId>
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button but = (Button) findViewById(R.id.button2);
        ScrollView sc = (ScrollView) findViewById(R.id.scroll);
        LinearLayout ly =  (LinearLayout) sc.getChildAt(0);

        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(getIntent());

            }
        });

        HttpHandler sh = new HttpHandler();

        String url ="https://api.coinranking.com/v1/public/coins/";
        String jsonStr = sh.makeServiceCall(url);

        if(jsonStr==null){
            sc.setVisibility(ScrollView.INVISIBLE);
            Toast.makeText(this, "No Connection",
                    Toast.LENGTH_LONG).show();
        }
        else{
            try {
                JSONObject jsonObj = new JSONObject(jsonStr);

                String ob = jsonObj.getString("status");
                JSONObject data = jsonObj.getJSONObject("data");

                coins = data.getJSONArray("coins");


                for(int i=0;i<40;i++){

                    String tag = "textView";
                    String price;
                    Integer a = i+2;
                    tag = tag+a.toString();
                    TextView v = (TextView) ly.getChildAt(i);
                    JSONObject tmp = coins.getJSONObject(i);
                    pairs.put(v.getId(),i);
                    String name = tmp.getString("symbol");
                    price = tmp.getString("price");
                    String color = tmp.getString("color");
                    price =  String.format("%.2f", Float.parseFloat(price));
                    name = name+"                                                   $ "+price;


                    v.setText(name);
                    if(color.length()!=4){
                        v.setTextColor(Color.parseColor(color));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }



    }

    public void click1(View v) throws JSONException {
        TextView tv = (TextView) findViewById(v.getId());

        Integer tvId = (Integer) tv.getId();
        Integer id = (Integer) pairs.get(tvId);
        JSONObject obj = coins.getJSONObject(id);

        String description = obj.getString("description");
        String name = obj.getString("name");
        String price = String.format("%.2f", Float.parseFloat(obj.getString("price")));
        String color = obj.getString("color");
        String url = obj.getString("iconUrl");

        if(description.compareTo("null")==0){
            description="No Description";
        }

        Intent i = new Intent(MainActivity.this,CoinGoster.class);
        i.putExtra("name",name);
        i.putExtra("description",description);
        i.putExtra("price",price);
        i.putExtra("url",url);
        i.putExtra("color",color);
        startActivity(i);
    }

}
